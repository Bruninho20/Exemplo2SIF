package teste;

import java.util.Scanner;

import Listas.ListaIntCrescente;

public class MainTeste {

	public static void main(String[] args) {
		ListaIntCrescente lista = new ListaIntCrescente();
		Scanner entrada = new Scanner(System.in);

		System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
		int valor = entrada.nextInt();

		while (valor >= 0) {
			lista.insere(valor);
			lista.show();
			System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
			valor = entrada.nextInt();
		}
		
		System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
		valor = entrada.nextInt();
		while (valor >= 0) {
			lista.remove(valor);
			lista.show();
			System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
			valor = entrada.nextInt();
		}
		entrada.close();
	}

}
