
public class Usuario {

		//Atributos / vari�veis de inst�ncia
		String nome;
		String cpf;
		String tipo; //estudante, professor, tarifa normals
		
		//codifica��o do construtor
		public Usuario(String nome, String cpf, String tipo) {
			this.nome = nome;
			this.cpf = cpf;
			this.tipo = tipo;
		}
	}


