package br.fiap.bonus;

public interface Bonus {
	public abstract double calcularBonus();
}
