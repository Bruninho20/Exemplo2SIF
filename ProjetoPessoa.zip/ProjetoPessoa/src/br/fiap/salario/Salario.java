package br.fiap.salario;

public interface Salario {
	public abstract double calcularSalario();
}
