
public class Main {

	public static void main(String[] args) {

		// array pra armazenar os objetos
		Reserva reserva[] = new Reserva[4];
		
		Hospede h1 = new Hospede("123", "Jo�o", 10);
		Hospede h2 = new Hospede("456", "Cleito", 4);
		Hospede h3 = new Hospede("789", "Yasmim", 25);
		Hospede h4 = new Hospede("987", "Bruna", 15);
		
		Resort r1 = new Resort("Rio de Janeiro", 5, "4741-1234");
		Resort r2 = new Resort("S�o Paulo", 8, "4844-1534");

		
		
	
	}

}
