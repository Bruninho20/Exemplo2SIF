
public class Reserva {

	String data;
	Resort resort;
	Hospede hospede;

	public Reserva(String data, Resort resort, Hospede hospede) {
		this.data = data;
		this.resort = resort;
		this.hospede = hospede;
	}

	public Reserva(Resort resort, Hospede hospede) {
		this.resort = resort;
		this.hospede = hospede;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Resort getResort() {
		return resort;
	}

	public void setResort(Resort resort) {
		this.resort = resort;
	}

	public Hospede getHospede() {
		return hospede;
	}

	public void setHospede(Hospede hospede) {
		this.hospede = hospede;
	}

	public String getDados() {
		String aux = "";
		aux += "Data: " + data;
		aux += "Resort" + resort;
		aux += "Hospede" + hospede;
		return aux;
	}

}
