
public class Hospede {

	String cpf;
	String nome;
	int pontuacao;

	public Hospede(String cpf, String nome, int pontuacao) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.pontuacao = pontuacao;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getPontuacao() {
		return pontuacao;
	}

	public void setPontuacao(int pontuacao) {
		this.pontuacao = pontuacao;
	}

	public String getDados() {
		String aux = "";
		aux += "CPF: " + cpf;
		aux += "Nome: " + nome;
		aux += "Pontua��o: " + pontuacao;
		return aux;
	}

}
