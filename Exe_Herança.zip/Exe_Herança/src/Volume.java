
public interface Volume {

	public abstract double calculaVolume();

}
