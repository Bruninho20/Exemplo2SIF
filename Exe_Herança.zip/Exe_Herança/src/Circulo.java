
public class Circulo extends Forma {

	
	public Circulo(int cX, int cY, double raio) {
		super(cX, cY, raio);
	}

	@Override
	public double calcularArea() {
		return 0;
	}
	
	
	
	
	
}
