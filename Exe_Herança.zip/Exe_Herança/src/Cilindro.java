
public class Cilindro extends Forma implements Volume {

	private double altura;

	public Cilindro(int cX, int cY, double raio, double altura) {
		super(cX, cY, raio);
		this.altura = altura;
	}

	@Override
	public double calcularArea() {
		return 0;
	}

	public double calculaVolume() {
		return 0;
	}

}
