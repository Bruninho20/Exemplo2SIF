package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.BilheteUnico;

public class BilheteUnicoDAO {
	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	
	// método para verificar se um número de bilhete está na base dados
	public boolean pesquisarNumero(int numero) {
		connection = new Conexao().conectar();
		sql = "select * from java_bilhete where numero = ?";
		boolean aux = false;
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, numero);
			rs = ps.executeQuery();
			aux = rs.next();
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar número do bilhete\n" + e);
		}
		
		return aux;		
	}

	
	// método para inserir os dados do bilhete na base dados
	public void inserir(BilheteUnico bilhete) {
		connection = new Conexao().conectar();
		sql = "insert into java_bilhete(numero, cpf, saldo, valorPassagem) values(?, ?, ?, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, bilhete.getNumero());
			ps.setString(2, bilhete.getCpf());
			ps.setDouble(3, bilhete.getSaldo());
			ps.setDouble(4, bilhete.getValorPassagem());
			ps.execute();  // ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir usuário pelo cpf\n" + e);
		}
	}
	
	public BilheteUnico pesquisarCpf(String cpf) {
		BilheteUnico bilhete = null;
		connection = new Conexao().conectar();
		sql = "select * from java_bilhete where numero = ?";
	
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			while(rs.next()) {
				bilhete = new BilheteUnico(rs.getInt("numero"), cpf, rs.getDouble("saldo"));
			}
			
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar número do bilhete\n" + e);
		}
		
		return bilhete;		
	}
	
	public List<BilheteUnico>listar(){
		List<BilheteUnico> lista = new ArrayList<BilheteUnico>();
		connection = new Conexao().conectar();
		sql="select * from java_bilhete";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				lista.add(new BilheteUnico(rs.getInt("numero"), rs.getString("cpf"), rs.getDouble("saldo")));
			}
			
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar número do bilhete\n" + e);
		}
		
		return lista;
	}
	
	
}
