package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.BilheteUnico;

public class BilheteUnicoDAO {
	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	
	public boolean pesquisarNumero(int numero) {
		boolean aux = false;
		connection = new Conexao().conectar();
		sql = "select * from java_bilhete where numero = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, numero);
			rs = ps.executeQuery();
			aux = rs.next();
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar o bilhete pelo número\n" + e);
		}
		
		return aux;
	}
	
	public void inserir(BilheteUnico bilhete) {
		connection = new Conexao().conectar();
		sql = "insert into java_bilhete(numero, cpf, saldo, valorPassagem) values(?, ?, ?, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, bilhete.getNumero());
			ps.setString(2, bilhete.getCpf());
			ps.setDouble(3, bilhete.getSaldo());
			ps.setDouble(4, bilhete.getValorPassagem());
			ps.execute();  // ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir bilhete\n" + e);
		}
	}

	public BilheteUnico pesquisarCpf(String cpf) {
		BilheteUnico bilhete = null;
		connection = new Conexao().conectar();
		sql = "select * from java_bilhete where cpf = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			while(rs.next()) {
				bilhete = new BilheteUnico(cpf);
			}
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar o bilhete pelo número\n" + e);
		}
		
		return bilhete;
	}
}
