package Exercicio03;

import java.util.Scanner;

import Filas.FilaString;

public class ConsultorioNome {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		FilaString f = new FilaString();

		int opc;
		do {
			System.out.println("1 - Inserir paciente na fila");
			System.out.println("2 - chama paciente para o atendimento");
			System.out.println("3 - Encerra atendimento do dia");
			System.out.println(" Op��o ");
			opc = entrada.nextInt();

			switch (opc) {
			case 1:
				System.out.println("Nome do paciente: ");
				String nome = entrada.next();
				
				break;
			case 2:
				if()
					System.out.println("Paciente chamado para atendimento: ");
				break;
			case 3:
				if()
					System.out.println("Ainda ha pacientes na fila");
				break;
			default:
				System.out.println("Op��o inv�lida");
			}
		} while (opc != 3);
		entrada.close();
		System.out.println("Atendimento encerrado!");
	}
}
