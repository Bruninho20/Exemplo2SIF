package exercicios;

import java.util.Scanner;

import Filas.*;

public class Exercicio01 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		filaInt f = new filaInt();
		f.init();
		System.out.println("Digite o valor positivo para enfileirar , ou negativo para sair");
		int valor = entrada.nextInt();

		while (valor >= 0) {
			// insere na fila o valor digitado
			f.enqueue(valor);
			System.out.println("Digite o valor positivo para enfileirar , ou negativo para sair");

			valor = entrada.nextInt();
		}
		entrada.close();

		while (f.isEmpty()) {
			System.out.println("Valor retirado da fila: " + f.dequeue());
			entrada.close();
		}
	}

}
