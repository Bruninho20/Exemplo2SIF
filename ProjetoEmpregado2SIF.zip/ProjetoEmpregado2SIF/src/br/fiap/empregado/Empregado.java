package br.fiap.empregado;

public abstract class Empregado {

	protected long matricula;
	protected String nome;
	
	// construtor para inicializar os atributos
	public Empregado(long matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}
	
	// m�todo para calcular e retornar o sal�rio
	public abstract double calcularSalario();
		
	// m�todo toString para retornar os dados do objeto
	@Override
	public String toString() {
		String aux = "";
		aux += "Matr�cula: " + matricula + "\n";
		aux += "Nome: " + nome + "\n";
		return aux;
	}

	public long getMatricula() {
		return matricula;
	}
	
	
	
}
